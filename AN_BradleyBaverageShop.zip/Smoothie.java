/*
 * Class: CMSC203 
 * Instructor: Prof. Ahmed Tarek
 * Description: You are asked to implement this software based on requirements
 * Due: 11/29/2021
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming assignment independently.
   I have not copied the code from a student or any source.
   I have not given my code to any student.
   Print your Name here: Aminata Ndiaye
*/

/**
 * @author Aminata Ndiaye
 */
public class Smoothie extends Beverage{
	private int numberOfFruits;
	private boolean addProtein;
	private final double FRUIT_Price = .5;
	private final double PROTEIN_Price = 1.5;

	/**
	 * Parameterized constructor  
	 * @param n
	 * @param s
	 * @param nof
	 * @param ap
	 */
	public Smoothie(String n, SIZE s, int nof, boolean ap) {
		super(n, TYPE.SMOOTHIE, s);
		numberOfFruits = nof;
		addProtein = ap;
	}

	
	 //Overridden toString method
	public String toString() {
		String s = getBevName() +", " +getSize() +" " +numberOfFruits +" Fruits";

		if (addProtein) {
			s += " Protein powder";
		}

		s += ", $" +calcPrice();

		return s;
	}
	
	//Overridden equals method
	public boolean equals(Smoothie s) {
		if (super.equals(s) && numberOfFruits==s.getNumOfFruits() 
				&& addProtein==s.getAddProtien()) {
			return true;
		}
		else {
			return false;
		}
	}
	
	//Overridden calcPrice method
	public double calcPrice() {
		double price = super.getBasePrice();

		if (super.getSize() == SIZE.MEDIUM) {
			price += super.getSizePrice();
		}
		else if (super.getSize() == SIZE.LARGE) {
			price += 2 * super.getSizePrice();
		}

		price += numberOfFruits * FRUIT_Price;
		if (addProtein) {
			price += PROTEIN_Price;
		}

		return price;
	}

	//Getters
	public int getNumOfFruits() {
		return numberOfFruits;
	}
	public boolean getAddProtien() {
		return addProtein;
	}
	public double getFruitCost() {
		return FRUIT_Price;
	}
	public double getProteinCost() {
		return PROTEIN_Price;
	}

	//Setters
	public void setNumOfFruits(int nof) {
		numberOfFruits = nof;
	}
	public void setProteinPowder(boolean ap) {
		addProtein = ap;
	}
}
