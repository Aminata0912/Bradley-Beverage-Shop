/*
 * Class: CMSC203 
 * Instructor: Prof. Ahmed Tarek
 * Description: You are asked to implement this software based on requirements
 * Due: 11/29/2021
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming assignment independently.
   I have not copied the code from a student or any source.
   I have not given my code to any student.
   Print your Name here: Aminata Ndiaye
*/

/**
 * @author Aminata Ndiaye
 */
public class Alcohol extends Beverage{
	private boolean isWeekend;
	private final double WEEKEND_FEE = .6;

	/**
	 * Parameterized constructor
	 * @param n
	 * @param s
	 * @param iw
	 */
	public Alcohol(String n, SIZE s, boolean iw) {
		super(n, TYPE.ALCOHOL, s);
		isWeekend = iw;
	}
	
	//Overridden toString method
	public String toString() {
		String s = getBevName() +", " +getSize();

		if (isWeekend) {
			s += " Weekend";
		}
		s += ", $" +calcPrice();
		return s;
	}
	
	//Overridden equals method
	public boolean equals(Alcohol a) {
		if (super.equals(a) && isWeekend == a.getIsWeekend()) {
			return true;
		}
		else {
			return false;
		}
	}
	
	//Overridden calcPrice method
	public double calcPrice() {
		double price = super.getBasePrice();

		if (super.getSize() == SIZE.MEDIUM) {
			price += super.getSizePrice();
		}
		else if (super.getSize() == SIZE.LARGE) {
			price += 2 * super.getSizePrice();
		}

		if (isWeekend) {
			price += WEEKEND_FEE;
		}

		return price;
	}
	public boolean getIsWeekend() {
		return isWeekend;
	}
	public double getWeekendFee() {
		return WEEKEND_FEE;
	}

	//Setter
	public void setIsWeekend(boolean is) {
		isWeekend = is;
	}
}
