/*
 * Class: CMSC203 
 * Instructor: Prof. Ahmed Tarek
 * Description: You are asked to implement this software based on requirements
 * Due: 11/29/2021
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming assignment independently.
   I have not copied the code from a student or any source.
   I have not given my code to any student.
   Print your Name here: Aminata Ndiaye
*/

/**
 * @author Aminata Ndiaye
 */
import java.util.ArrayList;
import java.util.Random;

class Order implements OrderInterface, Comparable<Order> {
	private int orderNo;
	private int orderTime;
	private DAY orderDay;
	private Customer customer;
	private ArrayList<Beverage> beverages;
	
	//Method to generate a random number within the range of 10000 and 90000
	public int genOrderNum() {
		Random rand = new Random();
		int randInt = rand.nextInt(90_000-10_000)+10_000;
		return randInt;
	}
	
	/**
	 * Parameterized constructor
	 * @param ot
	 * @param od
	 * @param c
	 */
	public Order(int ot, DAY od, Customer c) {
		orderNo = genOrderNum();
		orderTime = ot;
		orderDay = od;
		customer = c;
		beverages = new ArrayList<>();
	}
	
	//Method called addNewBeverage that adds a beverage to the order
		public void addNewBeverage(String name, SIZE size, boolean extraShot, boolean extraSyrup) {
			Coffee c = new Coffee(name, size, extraShot, extraSyrup);
			beverages.add(c);
		}
		public void addNewBeverage(String name, SIZE size, int numOfFruits, boolean proteinPowder) {
			Smoothie s = new Smoothie(name, size, numOfFruits, proteinPowder);
			beverages.add(s);
		}
		public void addNewBeverage(String name, SIZE size) {
			boolean isWeekend = false;
			if (orderDay == DAY.SATURDAY || orderDay == DAY.SUNDAY) {
				isWeekend = true;
			}
			Alcohol a = new Alcohol(name, size, isWeekend);
			beverages.add(a);
		}
	
		//Overridden toString method
	public String toString() {
		String s = "__________________________________"
				+orderDay.toString() +", " +orderTime
				+"\n" +customer.toString() +" Order Num: " +orderNo;

		for (Beverage b : beverages) {
			s += "\n" +b.toString();
		}
		s += "\n Order Total: " +calcOrderTotal();

		return s;
	}
	
	public boolean isWeekend() {
		if (orderDay == DAY.SATURDAY || orderDay == DAY.SUNDAY) {
			return true;
		}
		return false;
	}
	public Beverage getBeverage(int itemNum) {
		return beverages.get(itemNum);
	}
	public int compareTo1(Order o) {
		if (orderNo == o.getOrderNo()) {
			return 0;
		}
		else if (orderNo > o.getOrderNo()) {
			return 1;
		}
		else {
			return -1;
		}
	}
	public double calcOrderTotal() {
		double orderTotal = 0;

		for (Beverage b : beverages) {
			orderTotal += b.calcPrice();
		}

		return orderTotal;
	}
	public int findNumOfBeveType(TYPE type) {
		int count = 0;

		for (Beverage b : beverages) {
			if (b.getType() == type) {
				count++;
			}
		}

		return count;
	}
	public int getTotalItems() {
		return beverages.size();
	}

	//Getters
	public int getOrderNo() {
		return orderNo;
	}
	public int getOrderTime() {
		return orderTime;
	}
	public DAY getOrderDay() {
		return orderDay;
	}
	public Customer getCustomer() {
		return new Customer(customer);
	}
	public ArrayList<Beverage> getBeverages() {
		return beverages;
	}

	//Setters
	public void setOrderNum(int on) {
		orderNo = on;
	}
	public void setOrderTime(int ot) {
		orderTime = ot;
	}
	public void setOrderDay(DAY od) {
		orderDay = od;
	}
	public void setCustomer(Customer c) {
		customer = c;
	}
	@Override
	public int compareTo(Order arg0) {
		// TODO Auto-generated method stub
		return 0;
	}
}